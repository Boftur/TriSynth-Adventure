$(document).ready(function () {
    $("#title").focus();
    $("#text").autosize();
  });
  